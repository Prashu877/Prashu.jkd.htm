import React, { useState } from 'react';
import { ChevronDown, Filter } from 'lucide-react';

interface FilterOption {
  id: string;
  label: string;
}

interface FilterGroup {
  id: string;
  name: string;
  options: FilterOption[];
}

interface CategoryFilterProps {
  filterGroups: FilterGroup[];
  onFilterChange: (filters: Record<string, string[]>) => void;
  activeFilters: Record<string, string[]>;
}

const CategoryFilter: React.FC<CategoryFilterProps> = ({ 
  filterGroups, 
  onFilterChange,
  activeFilters
}) => {
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>({});
  const [isFilterVisible, setIsFilterVisible] = useState(false);

  const toggleGroup = (groupId: string) => {
    setOpenGroups(prev => ({
      ...prev,
      [groupId]: !prev[groupId]
    }));
  };

  const toggleFilter = (groupId: string, optionId: string) => {
    const currentGroupFilters = activeFilters[groupId] || [];
    let newGroupFilters;
    
    if (currentGroupFilters.includes(optionId)) {
      newGroupFilters = currentGroupFilters.filter(id => id !== optionId);
    } else {
      newGroupFilters = [...currentGroupFilters, optionId];
    }
    
    onFilterChange({
      ...activeFilters,
      [groupId]: newGroupFilters
    });
  };

  const clearAllFilters = () => {
    onFilterChange({});
  };

  const toggleMobileFilters = () => {
    setIsFilterVisible(!isFilterVisible);
  };

  // Count total active filters
  const activeFilterCount = Object.values(activeFilters).reduce(
    (count, filters) => count + filters.length, 
    0
  );

  return (
    <>
      {/* Mobile Filter Button */}
      <div className="md:hidden mb-4">
        <button
          onClick={toggleMobileFilters}
          className="w-full py-2 px-4 bg-white border border-gray-300 rounded-lg shadow-sm flex items-center justify-between"
        >
          <div className="flex items-center">
            <Filter className="h-4 w-4 mr-2" />
            <span>Filters</span>
            {activeFilterCount > 0 && (
              <span className="ml-2 bg-blue-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {activeFilterCount}
              </span>
            )}
          </div>
          <ChevronDown className={`h-4 w-4 transition-transform ${isFilterVisible ? 'rotate-180' : ''}`} />
        </button>
      </div>

      <div className={`md:block ${isFilterVisible ? 'block' : 'hidden'} bg-white p-4 rounded-lg shadow-sm`}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-medium text-gray-900">Filters</h3>
          {activeFilterCount > 0 && (
            <button
              onClick={clearAllFilters}
              className="text-sm text-blue-600 hover:text-blue-800"
            >
              Clear all
            </button>
          )}
        </div>

        <div className="space-y-4">
          {filterGroups.map((group) => (
            <div key={group.id} className="border-b border-gray-200 pb-4 last:border-b-0 last:pb-0">
              <button
                onClick={() => toggleGroup(group.id)}
                className="flex items-center justify-between w-full py-2 text-left font-medium text-gray-900"
              >
                <span>{group.name}</span>
                <ChevronDown className={`h-4 w-4 transition-transform ${openGroups[group.id] ? 'rotate-180' : ''}`} />
              </button>
              <div className={`mt-2 space-y-1 ${openGroups[group.id] ? 'block' : 'hidden'}`}>
                {group.options.map((option) => {
                  const isChecked = (activeFilters[group.id] || []).includes(option.id);
                  
                  return (
                    <label key={option.id} className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => toggleFilter(group.id, option.id)}
                        className="rounded text-blue-600 focus:ring-blue-500 h-4 w-4"
                      />
                      <span className="text-gray-600">{option.label}</span>
                    </label>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default CategoryFilter;