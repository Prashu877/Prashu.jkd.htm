import React, { useEffect, useState } from 'react';
import { ShoppingBag } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
}

const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [animationComplete, setAnimationComplete] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setAnimationComplete(true);
      setTimeout(onComplete, 500); // Wait for fade out animation
    }, 2500);

    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div 
      className={`fixed inset-0 bg-gradient-to-br from-blue-600 to-purple-700 flex flex-col items-center justify-center transition-opacity duration-500 z-50 ${
        animationComplete ? 'opacity-0' : 'opacity-100'
      }`}
    >
      <div className="text-white text-center">
        <div className="mb-4 relative">
          <ShoppingBag 
            size={72} 
            className="animate-bounce text-white opacity-90"
          />
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 h-16 w-16 bg-white rounded-full animate-ping opacity-20"></div>
        </div>
        <h1 className="text-4xl font-bold mb-2 animate-pulse bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">
          Prashu
        </h1>
        <p className="text-blue-200 animate-fadeIn">Fashion & Fun for Everyone</p>
      </div>
      <div className="absolute bottom-10 w-48 h-1 bg-blue-900 rounded-full overflow-hidden">
        <div className="h-full bg-white animate-progressBar"></div>
      </div>
    </div>
  );
};

export default SplashScreen;