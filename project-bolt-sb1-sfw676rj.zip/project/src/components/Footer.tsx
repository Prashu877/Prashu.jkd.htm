import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Mail, Phone, MapPin, CreditCard, Truck, RefreshCw } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent">Prashu</h2>
            <p className="text-gray-300 mb-4">Your one-stop shop for premium clothes and toys.</p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <Instagram size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/category/clothes" className="text-gray-300 hover:text-white transition-colors">Clothes</Link>
              </li>
              <li>
                <Link to="/category/toys" className="text-gray-300 hover:text-white transition-colors">Toys</Link>
              </li>
              <li>
                <Link to="/new-arrivals" className="text-gray-300 hover:text-white transition-colors">New Arrivals</Link>
              </li>
              <li>
                <Link to="/deals" className="text-gray-300 hover:text-white transition-colors">Deals & Offers</Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-300 hover:text-white transition-colors">About Us</Link>
              </li>
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h3 className="text-lg font-bold mb-4">Customer Service</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/contact" className="text-gray-300 hover:text-white transition-colors">Contact Us</Link>
              </li>
              <li>
                <Link to="/faq" className="text-gray-300 hover:text-white transition-colors">FAQ</Link>
              </li>
              <li>
                <Link to="/shipping" className="text-gray-300 hover:text-white transition-colors">Shipping Policy</Link>
              </li>
              <li>
                <Link to="/returns" className="text-gray-300 hover:text-white transition-colors">Returns & Refunds</Link>
              </li>
              <li>
                <Link to="/privacy" className="text-gray-300 hover:text-white transition-colors">Privacy Policy</Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-bold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-center space-x-3 text-gray-300">
                <MapPin size={18} />
                <span>123 Shopping Ave, Retail City</span>
              </li>
              <li className="flex items-center space-x-3 text-gray-300">
                <Phone size={18} />
                <span>+1 (234) 567-8901</span>
              </li>
              <li className="flex items-center space-x-3 text-gray-300">
                <Mail size={18} />
                <span>support@prashu.com</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Service Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-10 pt-8 border-t border-gray-800">
          <div className="flex items-center space-x-3 text-gray-300">
            <Truck className="text-blue-500" size={24} />
            <div>
              <h4 className="font-medium">Free Shipping</h4>
              <p className="text-sm text-gray-400">On orders over $50</p>
            </div>
          </div>
          <div className="flex items-center space-x-3 text-gray-300">
            <RefreshCw className="text-blue-500" size={24} />
            <div>
              <h4 className="font-medium">Easy Returns</h4>
              <p className="text-sm text-gray-400">30-day return policy</p>
            </div>
          </div>
          <div className="flex items-center space-x-3 text-gray-300">
            <CreditCard className="text-blue-500" size={24} />
            <div>
              <h4 className="font-medium">Secure Payments</h4>
              <p className="text-sm text-gray-400">Protected by encryption</p>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="mt-10 pt-6 border-t border-gray-800 text-center text-gray-400 text-sm">
          <p>&copy; {new Date().getFullYear()} Prashu. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;