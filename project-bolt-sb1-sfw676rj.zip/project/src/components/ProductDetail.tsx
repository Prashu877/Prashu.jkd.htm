import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Heart, ShoppingCart, Share2, Star, Truck, RefreshCw, Shield, ChevronRight } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { useWishlist } from '../contexts/WishlistContext';
import { Product, ProductVariant } from '../types';
import { findProductById } from '../data/products';
import ProductGrid from './ProductGrid';

const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const product = findProductById(id || '');
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [selectedVariants, setSelectedVariants] = useState<Record<string, ProductVariant>>({});
  
  const { addToCart } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  const [isInWishlistState, setIsInWishlistState] = useState(id ? isInWishlist(id) : false);

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h2 className="text-2xl font-bold mb-4">Product Not Found</h2>
        <p className="mb-8">Sorry, the product you're looking for doesn't exist.</p>
        <button 
          onClick={() => navigate('/')}
          className="px-6 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors"
        >
          Back to Home
        </button>
      </div>
    );
  }

  const handleAddToCart = () => {
    addToCart(product, quantity, Object.values(selectedVariants));
  };

  const handleWishlistToggle = () => {
    if (isInWishlistState) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
    setIsInWishlistState(!isInWishlistState);
  };

  const selectVariant = (type: string, variant: ProductVariant) => {
    setSelectedVariants(prev => ({
      ...prev,
      [type]: variant
    }));
  };

  // Similar products (would be based on real recommendations in a full app)
  const similarProducts = product.relatedProducts || [];

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex flex-col lg:flex-row -mx-4">
        {/* Product Images */}
        <div className="px-4 lg:w-3/5">
          <div className="mb-4 lg:sticky lg:top-24">
            <div className="aspect-w-1 aspect-h-1 mb-4">
              <img
                src={product.images ? product.images[selectedImage] : product.imageUrl}
                alt={product.name}
                className="w-full h-96 object-cover object-center rounded-xl"
              />
            </div>
            
            {product.images && product.images.length > 1 && (
              <div className="flex space-x-2 overflow-x-auto py-2">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`w-20 h-20 rounded-md overflow-hidden flex-shrink-0 border-2 ${
                      selectedImage === index ? 'border-blue-600' : 'border-transparent'
                    }`}
                  >
                    <img src={image} alt={`${product.name} - view ${index + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
        
        {/* Product Info */}
        <div className="px-4 lg:w-2/5">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">{product.name}</h1>
            
            <div className="flex items-center mb-4">
              <div className="flex mr-2">
                {Array.from({ length: 5 }).map((_, index) => (
                  <Star 
                    key={index}
                    className={`h-4 w-4 ${
                      index < Math.floor(product.rating) 
                        ? 'text-yellow-400 fill-current' 
                        : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>
              <span className="text-sm text-gray-600">{product.rating.toFixed(1)}</span>
              <span className="mx-2 text-gray-300">|</span>
              <span className="text-sm text-gray-600">{product.reviewCount} reviews</span>
            </div>
            
            <div className="mb-6">
              <div className="flex items-baseline mb-2">
                <span className="text-2xl font-bold text-gray-900">${product.currentPrice}</span>
                {product.originalPrice > product.currentPrice && (
                  <span className="ml-2 text-lg text-gray-500 line-through">
                    ${product.originalPrice}
                  </span>
                )}
                {product.discount > 0 && (
                  <span className="ml-2 px-2 py-0.5 bg-red-100 text-red-800 text-xs font-medium rounded">
                    Save {product.discount}%
                  </span>
                )}
              </div>
              
              <p className="text-sm text-gray-600">
                {product.stockCount > 10 
                  ? 'In Stock' 
                  : product.stockCount > 0 
                    ? `Only ${product.stockCount} left in stock!` 
                    : 'Out of Stock'
                }
              </p>
            </div>
            
            <div className="mb-6">
              <p className="text-gray-700 mb-4">{product.description}</p>
              
              <div className="flex flex-wrap gap-2 mb-1">
                {product.tags?.map((tag, index) => (
                  <span key={index} className="px-2 py-1 bg-gray-100 text-gray-800 text-xs rounded-full">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
            
            {/* Variants Selection (sizes, colors, etc.) */}
            {product.variants && Object.entries(product.variants).map(([type, options]) => (
              <div key={type} className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-2 capitalize">{type}</h3>
                <div className="flex flex-wrap gap-2">
                  {options.map((variant) => (
                    <button
                      key={variant.id}
                      onClick={() => selectVariant(type, variant)}
                      className={`px-4 py-2 border rounded-md text-sm ${
                        selectedVariants[type]?.id === variant.id
                          ? 'border-blue-600 bg-blue-50 text-blue-700'
                          : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      {variant.value}
                    </button>
                  ))}
                </div>
              </div>
            ))}
            
            {/* Quantity Selector */}
            <div className="mb-6">
              <h3 className="text-sm font-medium text-gray-900 mb-2">Quantity</h3>
              <div className="flex items-center">
                <button
                  onClick={() => quantity > 1 && setQuantity(quantity - 1)}
                  className="w-10 h-10 flex items-center justify-center border border-gray-300 rounded-l-md"
                >
                  -
                </button>
                <input
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-16 h-10 border-t border-b border-gray-300 text-center"
                />
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-10 h-10 flex items-center justify-center border border-gray-300 rounded-r-md"
                >
                  +
                </button>
              </div>
            </div>
            
            {/* Action Buttons */}
            <div className="flex space-x-4 mb-8">
              <button
                onClick={handleAddToCart}
                className="flex-1 py-3 px-6 bg-blue-600 hover:bg-blue-700 text-white rounded-full flex items-center justify-center space-x-2 transition-colors"
                disabled={product.stockCount === 0}
              >
                <ShoppingCart size={20} />
                <span>Add to Cart</span>
              </button>
              
              <button
                onClick={handleWishlistToggle}
                className={`p-3 rounded-full border ${
                  isInWishlistState
                    ? 'text-pink-500 border-pink-500'
                    : 'text-gray-600 border-gray-300 hover:border-gray-400'
                }`}
              >
                <Heart className={isInWishlistState ? 'fill-current' : ''} size={20} />
              </button>
              
              <button
                className="p-3 rounded-full border border-gray-300 text-gray-600 hover:border-gray-400"
              >
                <Share2 size={20} />
              </button>
            </div>
            
            {/* Shipping Info */}
            <div className="border-t border-gray-200 pt-6 space-y-4">
              <div className="flex items-start space-x-3">
                <Truck className="h-5 w-5 text-gray-400 mt-0.5" />
                <div>
                  <h3 className="text-sm font-medium text-gray-900">Free Shipping</h3>
                  <p className="text-sm text-gray-500">Free standard shipping on orders over $50</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <RefreshCw className="h-5 w-5 text-gray-400 mt-0.5" />
                <div>
                  <h3 className="text-sm font-medium text-gray-900">Easy Returns</h3>
                  <p className="text-sm text-gray-500">30-day return policy</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Shield className="h-5 w-5 text-gray-400 mt-0.5" />
                <div>
                  <h3 className="text-sm font-medium text-gray-900">Secure Payments</h3>
                  <p className="text-sm text-gray-500">All payments are securely processed</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Similar Products */}
      {similarProducts.length > 0 && (
        <div className="mt-16">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">You might also like</h2>
            <a href="#" className="text-blue-600 hover:text-blue-800 flex items-center">
              <span>View all</span>
              <ChevronRight size={16} />
            </a>
          </div>
          <ProductGrid products={similarProducts} />
        </div>
      )}
      
      {/* Reviews Section would go here */}
    </div>
  );
};

export default ProductDetail;