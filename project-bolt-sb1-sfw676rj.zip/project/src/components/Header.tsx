import React, { useState, useEffect } from 'react';
import { ShoppingCart, Heart, User, Search, Menu, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useCart } from '../contexts/CartContext';
import { useWishlist } from '../contexts/WishlistContext';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { cartItems } = useCart();
  const { wishlistItems } = useWishlist();
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Implement search functionality
    console.log('Searching for:', searchQuery);
  };

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Prashu
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link to="/category/clothes" className="font-medium hover:text-blue-600 transition-colors">
              Clothes
            </Link>
            <Link to="/category/shoes" className="font-medium hover:text-blue-600 transition-colors">
              Shoes
            </Link>
            <Link to="/category/toys" className="font-medium hover:text-blue-600 transition-colors">
              Toys
            </Link>
            <Link to="/new-arrivals" className="font-medium hover:text-blue-600 transition-colors">
              New Arrivals
            </Link>
            <Link to="/deals" className="font-medium hover:text-blue-600 transition-colors">
              Deals
            </Link>
          </nav>

          {/* Search Bar */}
          <div className="hidden md:block flex-1 max-w-md mx-4">
            <form onSubmit={handleSearch} className="relative">
              <input
                type="text"
                placeholder="Search products..."
                className="w-full py-2 pl-10 pr-4 bg-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </form>
          </div>

          {/* Icons */}
          <div className="flex items-center space-x-4">
            <Link to="/wishlist" className="relative p-2 hover:bg-gray-100 rounded-full transition-colors">
              <Heart className="h-6 w-6" />
              {wishlistItems.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-pink-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                  {wishlistItems.length}
                </span>
              )}
            </Link>
            <Link to="/cart" className="relative p-2 hover:bg-gray-100 rounded-full transition-colors">
              <ShoppingCart className="h-6 w-6" />
              {cartItems.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-blue-600 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                  {cartItems.length}
                </span>
              )}
            </Link>
            <Link to="/account" className="p-2 hover:bg-gray-100 rounded-full transition-colors">
              <User className="h-6 w-6" />
            </Link>
            <button
              onClick={toggleMenu}
              className="p-2 md:hidden hover:bg-gray-100 rounded-full transition-colors"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 py-4 bg-white rounded-lg shadow-lg animate-fadeIn">
            <div className="px-4 pb-4">
              <form onSubmit={handleSearch} className="relative">
                <input
                  type="text"
                  placeholder="Search products..."
                  className="w-full py-2 pl-10 pr-4 bg-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              </form>
            </div>
            <div className="flex flex-col space-y-2">
              <Link 
                to="/category/clothes" 
                className="py-2 px-4 hover:bg-gray-100 font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                Clothes
              </Link>
              <Link 
                to="/category/shoes" 
                className="py-2 px-4 hover:bg-gray-100 font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                Shoes
              </Link>
              <Link 
                to="/category/toys" 
                className="py-2 px-4 hover:bg-gray-100 font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                Toys
              </Link>
              <Link 
                to="/new-arrivals" 
                className="py-2 px-4 hover:bg-gray-100 font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                New Arrivals
              </Link>
              <Link 
                to="/deals" 
                className="py-2 px-4 hover:bg-gray-100 font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                Deals
              </Link>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;