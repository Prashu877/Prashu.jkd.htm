import React from 'react';
import { Trash2, Plus, Minus } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { CartItem as CartItemType } from '../types';

interface CartItemProps {
  item: CartItemType;
}

const CartItem: React.FC<CartItemProps> = ({ item }) => {
  const { updateQuantity, removeFromCart } = useCart();
  
  const handleQuantityChange = (newQuantity: number) => {
    if (newQuantity >= 1) {
      updateQuantity(item.product.id, newQuantity);
    }
  };

  return (
    <div className="flex items-center py-4 border-b border-gray-200 last:border-b-0">
      <div className="w-20 h-20 flex-shrink-0 bg-gray-100 rounded-lg overflow-hidden">
        <img 
          src={item.product.imageUrl} 
          alt={item.product.name} 
          className="w-full h-full object-cover"
        />
      </div>
      
      <div className="ml-4 flex-grow">
        <h3 className="text-sm md:text-base font-medium text-gray-900">{item.product.name}</h3>
        <p className="text-xs text-gray-500 mb-1">
          {item.product.category} | {item.selectedVariant && `${item.selectedVariant.name}: ${item.selectedVariant.value}`}
        </p>
        <div className="flex items-baseline">
          <span className="font-medium text-gray-900">${item.product.currentPrice}</span>
          {item.product.originalPrice > item.product.currentPrice && (
            <span className="ml-2 text-xs text-gray-500 line-through">
              ${item.product.originalPrice}
            </span>
          )}
        </div>
      </div>
      
      <div className="flex items-center ml-4">
        <div className="flex items-center border border-gray-300 rounded-full">
          <button
            onClick={() => handleQuantityChange(item.quantity - 1)}
            className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-gray-900 focus:outline-none"
          >
            <Minus size={16} />
          </button>
          <span className="w-8 text-center text-sm">{item.quantity}</span>
          <button
            onClick={() => handleQuantityChange(item.quantity + 1)}
            className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-gray-900 focus:outline-none"
          >
            <Plus size={16} />
          </button>
        </div>
        
        <button
          onClick={() => removeFromCart(item.product.id)}
          className="ml-4 p-2 text-gray-400 hover:text-red-500 focus:outline-none transition-colors"
          aria-label="Remove item"
        >
          <Trash2 size={18} />
        </button>
      </div>
    </div>
  );
};

export default CartItem;