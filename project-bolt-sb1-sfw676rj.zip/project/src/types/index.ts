// Product Types
export interface ProductVariant {
  id: string;
  name?: string;
  value: string;
  available?: boolean;
}

export interface Product {
  id: string;
  name: string;
  brand: string;
  category: string;
  description: string;
  imageUrl: string;
  images?: string[];
  currentPrice: number;
  originalPrice: number;
  discount: number;
  rating: number;
  reviewCount: number;
  stockCount: number;
  popularity: number;
  dateAdded: string;
  tags?: string[];
  variants?: {
    [key: string]: ProductVariant[];
  };
  features?: string[];
  specifications?: Record<string, string>;
  relatedProducts?: Product[];
}

// Cart Types
export interface CartItem {
  product: Product;
  quantity: number;
  selectedVariant?: ProductVariant;
}

// User Types
export interface UserAddress {
  id: string;
  fullName: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  isDefault: boolean;
  phone: string;
}

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  addresses: UserAddress[];
}

// Order Types
export interface Order {
  id: string;
  userId: string;
  items: CartItem[];
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  shippingAddress: UserAddress;
  paymentMethod: string;
  subtotal: number;
  tax: number;
  shippingCost: number;
  total: number;
  createdAt: string;
  updatedAt: string;
  trackingNumber?: string;
  estimatedDelivery?: string;
}

// Review Types
export interface Review {
  id: string;
  productId: string;
  userId: string;
  userName: string;
  rating: number;
  title: string;
  comment: string;
  date: string;
  helpful: number;
  verified: boolean;
}