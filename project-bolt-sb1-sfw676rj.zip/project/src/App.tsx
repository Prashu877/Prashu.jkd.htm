import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import SplashScreen from './components/SplashScreen';
import HomePage from './pages/HomePage';
import CategoryPage from './pages/CategoryPage';
import ProductDetail from './components/ProductDetail';
import CartPage from './pages/CartPage';
import { CartProvider } from './contexts/CartContext';
import { WishlistProvider } from './contexts/WishlistContext';

function App() {
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    // Check if the app has been loaded before
    const hasVisited = localStorage.getItem('hasVisited');
    if (hasVisited) {
      setShowSplash(false);
    } else {
      // Set the flag for future visits
      localStorage.setItem('hasVisited', 'true');
    }
  }, []);

  const handleSplashComplete = () => {
    setShowSplash(false);
  };

  return (
    <CartProvider>
      <WishlistProvider>
        <Router>
          <div className="min-h-screen flex flex-col bg-gray-50">
            {showSplash ? (
              <SplashScreen onComplete={handleSplashComplete} />
            ) : (
              <>
                <Header />
                <main className="flex-grow">
                  <Routes>
                    <Route path="/" element={<HomePage />} />
                    <Route path="/category/:categoryId" element={<CategoryPage />} />
                    <Route path="/product/:id" element={<ProductDetail />} />
                    <Route path="/cart" element={<CartPage />} />
                    {/* Add more routes as needed */}
                  </Routes>
                </main>
                <Footer />
              </>
            )}
          </div>
        </Router>
      </WishlistProvider>
    </CartProvider>
  );
}

export default App;