import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, CartItem, ProductVariant } from '../types';

interface CartContextType {
  cartItems: CartItem[];
  addToCart: (product: Product, quantity?: number, selectedVariants?: ProductVariant[]) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  itemCount: number;
  cartTotal: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [itemCount, setItemCount] = useState(0);
  const [cartTotal, setCartTotal] = useState(0);

  // Load cart from localStorage on initial load
  useEffect(() => {
    const savedCart = localStorage.getItem('cart');
    if (savedCart) {
      try {
        const parsedCart = JSON.parse(savedCart);
        setCartItems(parsedCart);
      } catch (error) {
        console.error('Failed to parse cart from localStorage:', error);
        localStorage.removeItem('cart');
      }
    }
  }, []);

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    if (cartItems.length > 0) {
      localStorage.setItem('cart', JSON.stringify(cartItems));
    } else {
      localStorage.removeItem('cart');
    }
    
    // Update item count and total
    const count = cartItems.reduce((total, item) => total + item.quantity, 0);
    setItemCount(count);
    
    const total = cartItems.reduce(
      (sum, item) => sum + item.product.currentPrice * item.quantity, 
      0
    );
    setCartTotal(total);
  }, [cartItems]);

  const addToCart = (product: Product, quantity = 1, selectedVariants: ProductVariant[] = []) => {
    setCartItems(prevItems => {
      // Check if this product with the same variants already exists in cart
      const selectedVariant = selectedVariants.length > 0 ? selectedVariants[0] : undefined;
      const existingItemIndex = prevItems.findIndex(item => {
        const sameProduct = item.product.id === product.id;
        
        // If no variants are selected, just check the product
        if (!selectedVariant && !item.selectedVariant) {
          return sameProduct;
        }
        
        // If variants differ, it's a different item
        if (
          (!selectedVariant && item.selectedVariant) || 
          (selectedVariant && !item.selectedVariant)
        ) {
          return false;
        }
        
        // Check if the variants match
        return sameProduct && 
          selectedVariant?.id === item.selectedVariant?.id;
      });
      
      if (existingItemIndex >= 0) {
        // Update quantity of existing item
        const updatedItems = [...prevItems];
        updatedItems[existingItemIndex].quantity += quantity;
        return updatedItems;
      } else {
        // Add new item
        return [...prevItems, { 
          product, 
          quantity, 
          selectedVariant: selectedVariants.length > 0 ? selectedVariants[0] : undefined 
        }];
      }
    });
  };

  const removeFromCart = (productId: string) => {
    setCartItems(prevItems => prevItems.filter(item => item.product.id !== productId));
  };

  const updateQuantity = (productId: string, quantity: number) => {
    setCartItems(prevItems =>
      prevItems.map(item =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setCartItems([]);
  };

  return (
    <CartContext.Provider
      value={{
        cartItems,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        itemCount,
        cartTotal
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};