import { Product } from '../types';

// Helper function to generate a random product
const generateProduct = (
  id: string, 
  name: string, 
  category: string, 
  price: number, 
  discount: number = 0,
  stockCount: number = Math.floor(Math.random() * 50) + 10
): Product => {
  const originalPrice = price;
  const currentPrice = discount > 0 ? originalPrice * (1 - discount / 100) : originalPrice;
  
  return {
    id,
    name,
    brand: ['Nike', 'Adidas', 'Puma', 'H&M', 'Zara', 'Levi\'s', 'LEGO', 'Hasbro', 'Mattel', 'Fisher-Price'][
      Math.floor(Math.random() * 10)
    ],
    category,
    description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, velit vel bibendum bibendum, est nisl ultricies nisl, eget aliquam nisl nisl sit amet nisl.',
    imageUrl: category === 'clothes' 
      ? `https://images.pexels.com/photos/${[3755706, 5886041, 5699021, 6764043, 2058664, 2709563][Math.floor(Math.random() * 6)]}/pexels-photo-${[3755706, 5886041, 5699021, 6764043, 2058664, 2709563][Math.floor(Math.random() * 6)]}.jpeg?auto=compress&cs=tinysrgb&w=600`
      : category === 'shoes'
      ? `https://images.pexels.com/photos/${[2529148, 1598505, 1478442, 1598508, 1464625, 1464624][Math.floor(Math.random() * 6)]}/pexels-photo-${[2529148, 1598505, 1478442, 1598508, 1464625, 1464624][Math.floor(Math.random() * 6)]}.jpeg?auto=compress&cs=tinysrgb&w=600`
      : `https://images.pexels.com/photos/${[163036, 163025, 264905, 133539, 207891, 210795][Math.floor(Math.random() * 6)]}/pexels-photo-${[163036, 163025, 264905, 133539, 207891, 210795][Math.floor(Math.random() * 6)]}.jpeg?auto=compress&cs=tinysrgb&w=600`,
    images: Array(4).fill(null).map(() => 
      category === 'clothes' 
        ? `https://images.pexels.com/photos/${[3755706, 5886041, 5699021, 6764043, 2058664, 2709563][Math.floor(Math.random() * 6)]}/pexels-photo-${[3755706, 5886041, 5699021, 6764043, 2058664, 2709563][Math.floor(Math.random() * 6)]}.jpeg?auto=compress&cs=tinysrgb&w=600`
        : category === 'shoes'
        ? `https://images.pexels.com/photos/${[2529148, 1598505, 1478442, 1598508, 1464625, 1464624][Math.floor(Math.random() * 6)]}/pexels-photo-${[2529148, 1598505, 1478442, 1598508, 1464625, 1464624][Math.floor(Math.random() * 6)]}.jpeg?auto=compress&cs=tinysrgb&w=600`
        : `https://images.pexels.com/photos/${[163036, 163025, 264905, 133539, 207891, 210795][Math.floor(Math.random() * 6)]}/pexels-photo-${[163036, 163025, 264905, 133539, 207891, 210795][Math.floor(Math.random() * 6)]}.jpeg?auto=compress&cs=tinysrgb&w=600`
    ),
    currentPrice,
    originalPrice,
    discount,
    rating: Math.random() * 2 + 3, // Rating between 3 and 5
    reviewCount: Math.floor(Math.random() * 500),
    stockCount,
    popularity: Math.floor(Math.random() * 100),
    dateAdded: new Date(Date.now() - Math.floor(Math.random() * 90) * 24 * 60 * 60 * 1000).toISOString(),
    tags: ['new', 'featured', 'bestseller', 'sale'].filter(() => Math.random() > 0.7),
    variants: category === 'clothes' 
      ? {
          sizes: [
            { id: 'xs', value: 'XS', available: Math.random() > 0.2 },
            { id: 's', value: 'S', available: Math.random() > 0.2 },
            { id: 'm', value: 'M', available: Math.random() > 0.2 },
            { id: 'l', value: 'L', available: Math.random() > 0.2 },
            { id: 'xl', value: 'XL', available: Math.random() > 0.2 },
            { id: 'xxl', value: 'XXL', available: Math.random() > 0.7 },
          ],
          colors: [
            { id: 'black', value: 'Black', available: Math.random() > 0.2 },
            { id: 'white', value: 'White', available: Math.random() > 0.2 },
            { id: 'blue', value: 'Blue', available: Math.random() > 0.5 },
            { id: 'red', value: 'Red', available: Math.random() > 0.5 },
            { id: 'green', value: 'Green', available: Math.random() > 0.7 },
          ]
        }
      : category === 'shoes'
      ? {
          sizes: [
            { id: '36', value: '36 EU', available: Math.random() > 0.2 },
            { id: '37', value: '37 EU', available: Math.random() > 0.2 },
            { id: '38', value: '38 EU', available: Math.random() > 0.2 },
            { id: '39', value: '39 EU', available: Math.random() > 0.2 },
            { id: '40', value: '40 EU', available: Math.random() > 0.2 },
            { id: '41', value: '41 EU', available: Math.random() > 0.2 },
            { id: '42', value: '42 EU', available: Math.random() > 0.2 },
          ],
          colors: [
            { id: 'black', value: 'Black', available: Math.random() > 0.2 },
            { id: 'white', value: 'White', available: Math.random() > 0.2 },
            { id: 'brown', value: 'Brown', available: Math.random() > 0.5 },
            { id: 'blue', value: 'Blue', available: Math.random() > 0.5 },
          ]
        }
      : {
          ageGroups: [
            { id: '0-2', value: '0-2 years', available: Math.random() > 0.7 },
            { id: '3-5', value: '3-5 years', available: Math.random() > 0.3 },
            { id: '6-8', value: '6-8 years', available: Math.random() > 0.3 },
            { id: '9-12', value: '9-12 years', available: Math.random() > 0.5 },
            { id: '12+', value: '12+ years', available: Math.random() > 0.7 },
          ]
        }
  };
};

// Generate shoes products
const shoesProducts: Product[] = [
  generateProduct('s1', 'Classic Oxford Shoes', 'shoes', 89.99, 0),
  generateProduct('s2', 'Comfortable Running Shoes', 'shoes', 129.99, 15),
  generateProduct('s3', 'Elegant High Heels', 'shoes', 99.99, 20),
  generateProduct('s4', 'Casual Sneakers', 'shoes', 79.99, 0),
  generateProduct('s5', 'Leather Loafers', 'shoes', 119.99, 10),
  generateProduct('s6', 'Summer Sandals', 'shoes', 59.99, 0),
  generateProduct('s7', 'Formal Dress Shoes', 'shoes', 149.99, 25),
  generateProduct('s8', 'Athletic Sports Shoes', 'shoes', 109.99, 0),
  generateProduct('s9', 'Comfortable Flats', 'shoes', 69.99, 0),
  generateProduct('s10', 'Ankle Boots', 'shoes', 139.99, 15),
  generateProduct('s11', 'Canvas Shoes', 'shoes', 49.99, 0),
  generateProduct('s12', 'Walking Shoes', 'shoes', 89.99, 10),
];

// Generate clothing products
const clothingProducts: Product[] = [
  generateProduct('c1', 'Classic Cotton T-Shirt', 'clothes', 29.99, 0),
  generateProduct('c2', 'Slim Fit Jeans', 'clothes', 59.99, 10),
  generateProduct('c3', 'Casual Button-Down Shirt', 'clothes', 44.99, 15),
  generateProduct('c4', 'Summer Floral Dress', 'clothes', 69.99, 20),
  generateProduct('c5', 'Athletic Performance Shorts', 'clothes', 34.99, 0),
  generateProduct('c6', 'Lightweight Hoodie', 'clothes', 49.99, 0),
  generateProduct('c7', 'Formal Blazer', 'clothes', 129.99, 25),
  generateProduct('c8', 'Printed Graphic Tee', 'clothes', 24.99, 0),
  generateProduct('c9', 'Cargo Pants', 'clothes', 54.99, 0),
  generateProduct('c10', 'Knit Sweater', 'clothes', 64.99, 15),
  generateProduct('c11', 'Denim Jacket', 'clothes', 89.99, 10),
  generateProduct('c12', 'Yoga Leggings', 'clothes', 39.99, 0),
];

// Generate toy products
const toyProducts: Product[] = [
  generateProduct('t1', 'Building Blocks Set', 'toys', 24.99, 0),
  generateProduct('t2', 'Remote Control Car', 'toys', 49.99, 10),
  generateProduct('t3', 'Interactive Learning Tablet', 'toys', 69.99, 15),
  generateProduct('t4', 'Plush Teddy Bear', 'toys', 19.99, 0),
  generateProduct('t5', 'Science Experiment Kit', 'toys', 39.99, 0),
  generateProduct('t6', 'Dollhouse Mansion', 'toys', 129.99, 20),
  generateProduct('t7', 'Board Game Collection', 'toys', 29.99, 0),
  generateProduct('t8', 'Action Figure Set', 'toys', 34.99, 0),
  generateProduct('t9', 'Art and Craft Kit', 'toys', 24.99, 0),
  generateProduct('t10', 'Educational Puzzle', 'toys', 19.99, 0),
  generateProduct('t11', 'Outdoor Play Set', 'toys', 199.99, 25),
  generateProduct('t12', 'Musical Keyboard', 'toys', 59.99, 10),
];

// Add related products to each product
shoesProducts.forEach(product => {
  const relatedProducts = shoesProducts
    .filter(p => p.id !== product.id)
    .sort(() => 0.5 - Math.random())
    .slice(0, 4);
  
  product.relatedProducts = relatedProducts;
});

clothingProducts.forEach(product => {
  const relatedProducts = clothingProducts
    .filter(p => p.id !== product.id)
    .sort(() => 0.5 - Math.random())
    .slice(0, 4);
  
  product.relatedProducts = relatedProducts;
});

toyProducts.forEach(product => {
  const relatedProducts = toyProducts
    .filter(p => p.id !== product.id)
    .sort(() => 0.5 - Math.random())
    .slice(0, 4);
  
  product.relatedProducts = relatedProducts;
});

// Combine all products
const allProducts: Product[] = [...clothingProducts, ...shoesProducts, ...toyProducts];

// Function to get products by category
export const getProductsByCategory = (category: string): Product[] => {
  return allProducts.filter(product => product.category === category);
};

// Function to get a single product by ID
export const findProductById = (id: string): Product | undefined => {
  return allProducts.find(product => product.id === id);
};

// Function to get featured products
export const getFeaturedProducts = (): Product[] => {
  return allProducts
    .filter(product => product.discount > 0 || product.tags?.includes('featured'))
    .sort(() => 0.5 - Math.random())
    .slice(0, 8);
};

// Function to get new arrivals
export const getNewArrivals = (): Product[] => {
  return allProducts
    .sort((a, b) => new Date(b.dateAdded).getTime() - new Date(a.dateAdded).getTime())
    .slice(0, 8);
};

// Function to get trending products
export const getTrendingProducts = (): Product[] => {
  return allProducts
    .sort((a, b) => b.popularity - a.popularity)
    .slice(0, 8);
};