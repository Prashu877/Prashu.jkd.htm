import React, { useEffect, useState } from 'react';
import { ChevronRight, TrendingUp, Tag, Clock, ArrowRight, Gift, Truck } from 'lucide-react';
import { Link } from 'react-router-dom';
import ProductGrid from '../components/ProductGrid';
import { getFeaturedProducts, getNewArrivals, getTrendingProducts } from '../data/products';
import { Product } from '../types';

const HomePage: React.FC = () => {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [newArrivals, setNewArrivals] = useState<Product[]>([]);
  const [trendingProducts, setTrendingProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate API calls with a delay
    const timer = setTimeout(() => {
      setFeaturedProducts(getFeaturedProducts());
      setNewArrivals(getNewArrivals());
      setTrendingProducts(getTrendingProducts());
      setIsLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-r from-blue-600 to-indigo-700 py-16 md:py-24">
        <div className="container mx-auto px-4 z-10 relative">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 text-center md:text-left mb-8 md:mb-0">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 leading-tight">
                Summer Collection <br />
                <span className="text-yellow-300">2025</span>
              </h1>
              <p className="text-blue-100 text-lg md:text-xl mb-8 max-w-lg">
                Discover the latest fashion trends and toys for the season. Shop now for exclusive deals!
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 justify-center md:justify-start">
                <Link 
                  to="/category/clothes" 
                  className="px-8 py-3 bg-white text-blue-700 rounded-full font-medium hover:bg-gray-100 transition-colors shadow-lg"
                >
                  Shop Clothes
                </Link>
                <Link 
                  to="/category/shoes" 
                  className="px-8 py-3 bg-transparent text-white border-2 border-white rounded-full font-medium hover:bg-white/10 transition-colors"
                >
                  Shop Shoes
                </Link>
              </div>
            </div>
            <div className="md:w-1/2">
              <img 
                src="https://images.pexels.com/photos/5872361/pexels-photo-5872361.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Summer Collection" 
                className="rounded-lg shadow-xl mx-auto transform hover:scale-105 transition-transform duration-500 max-w-full"
              />
            </div>
          </div>
        </div>
        <div className="absolute inset-0 bg-pattern opacity-10"></div>
      </div>

      {/* Categories Section */}
      <div className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-center mb-12">Shop by Category</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Link to="/category/clothes" className="relative overflow-hidden rounded-xl group">
            <img 
              src="https://images.pexels.com/photos/996329/pexels-photo-996329.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
              alt="Clothes Category" 
              className="w-full h-80 object-cover transition-transform duration-500 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
              <div className="p-6">
                <h3 className="text-2xl font-bold text-white mb-2">Clothes</h3>
                <p className="text-gray-200 mb-4">Explore our latest fashion collection</p>
                <span className="inline-flex items-center text-white font-medium">
                  Shop Now
                  <ArrowRight className="ml-2 h-4 w-4" />
                </span>
              </div>
            </div>
          </Link>
          <Link to="/category/shoes" className="relative overflow-hidden rounded-xl group">
            <img 
              src="https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
              alt="Shoes Category" 
              className="w-full h-80 object-cover transition-transform duration-500 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
              <div className="p-6">
                <h3 className="text-2xl font-bold text-white mb-2">Shoes</h3>
                <p className="text-gray-200 mb-4">Step into style with our shoe collection</p>
                <span className="inline-flex items-center text-white font-medium">
                  Shop Now
                  <ArrowRight className="ml-2 h-4 w-4" />
                </span>
              </div>
            </div>
          </Link>
          <Link to="/category/toys" className="relative overflow-hidden rounded-xl group">
            <img 
              src="https://images.pexels.com/photos/163036/mario-luigi-yoschi-figures-163036.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
              alt="Toys Category" 
              className="w-full h-80 object-cover transition-transform duration-500 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
              <div className="p-6">
                <h3 className="text-2xl font-bold text-white mb-2">Toys</h3>
                <p className="text-gray-200 mb-4">Find the perfect toys for all ages</p>
                <span className="inline-flex items-center text-white font-medium">
                  Shop Now
                  <ArrowRight className="ml-2 h-4 w-4" />
                </span>
              </div>
            </div>
          </Link>
        </div>
      </div>

      {/* Featured Products */}
      <div className="bg-gray-50 py-16">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold text-gray-900">Featured Products</h2>
            <Link to="/featured" className="text-blue-600 hover:text-blue-800 flex items-center">
              <span>View all</span>
              <ChevronRight size={16} />
            </Link>
          </div>
          <ProductGrid products={featuredProducts} isLoading={isLoading} />
        </div>
      </div>

      {/* Promo Banner */}
      <div className="bg-gradient-to-r from-purple-600 to-pink-500 py-12 md:py-16 my-16">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Summer Sale!</h2>
            <p className="text-purple-100 text-lg mb-8">
              Get amazing deals on selected items. Limited time offer!
            </p>
            <Link 
              to="/deals" 
              className="inline-block px-8 py-3 bg-white text-purple-700 rounded-full font-medium hover:bg-gray-100 transition-colors shadow-md"
            >
              Shop Now
            </Link>
          </div>
        </div>
      </div>

      {/* New Arrivals */}
      <div className="container mx-auto px-4 py-16">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center">
            <Clock className="h-6 w-6 text-blue-600 mr-2" />
            <h2 className="text-2xl font-bold text-gray-900">New Arrivals</h2>
          </div>
          <Link to="/new-arrivals" className="text-blue-600 hover:text-blue-800 flex items-center">
            <span>View all</span>
            <ChevronRight size={16} />
          </Link>
        </div>
        <ProductGrid products={newArrivals} isLoading={isLoading} />
      </div>

      {/* Trending Section */}
      <div className="bg-gray-50 py-16">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center">
              <TrendingUp className="h-6 w-6 text-blue-600 mr-2" />
              <h2 className="text-2xl font-bold text-gray-900">Trending Now</h2>
            </div>
            <Link to="/trending" className="text-blue-600 hover:text-blue-800 flex items-center">
              <span>View all</span>
              <ChevronRight size={16} />
            </Link>
          </div>
          <ProductGrid products={trendingProducts} isLoading={isLoading} />
        </div>
      </div>

      {/* Features Banner */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white p-6 rounded-xl shadow-sm text-center">
            <div className="w-12 h-12 mx-auto mb-4 bg-blue-100 rounded-full flex items-center justify-center">
              <Truck className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="text-lg font-bold mb-2">Fast Delivery</h3>
            <p className="text-gray-600">Get your products delivered to your doorstep quickly and securely.</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-sm text-center">
            <div className="w-12 h-12 mx-auto mb-4 bg-blue-100 rounded-full flex items-center justify-center">
              <Tag className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="text-lg font-bold mb-2">Quality Products</h3>
            <p className="text-gray-600">We offer only the highest quality products you can trust.</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-sm text-center">
            <div className="w-12 h-12 mx-auto mb-4 bg-blue-100 rounded-full flex items-center justify-center">
              <Gift className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="text-lg font-bold mb-2">Special Offers</h3>
            <p className="text-gray-600">Regular discounts and special offers for our loyal customers.</p>
          </div>
        </div>
      </div>

      {/* Newsletter */}
      <div className="bg-gray-900 py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-white mb-4">Join Our Newsletter</h2>
            <p className="text-gray-300 mb-8">
              Subscribe to our newsletter and be the first to know about our new arrivals and special offers.
            </p>
            <form className="flex flex-col md:flex-row mx-auto max-w-lg gap-2">
              <input
                type="email"
                placeholder="Your email address"
                className="flex-grow px-4 py-3 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                type="submit"
                className="px-6 py-3 bg-blue-600 text-white rounded-full font-medium hover:bg-blue-700 transition-colors"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;