import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Filter, Grid, List } from 'lucide-react';
import ProductGrid from '../components/ProductGrid';
import CategoryFilter from '../components/CategoryFilter';
import { getProductsByCategory } from '../data/products';
import { Product } from '../types';

const CategoryPage: React.FC = () => {
  const { categoryId } = useParams<{ categoryId: string }>();
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isFilterVisible, setIsFilterVisible] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState('popularity');
  const [activeFilters, setActiveFilters] = useState<Record<string, string[]>>({});

  useEffect(() => {
    // Reset state when category changes
    setIsLoading(true);
    setActiveFilters({});
    
    // Simulate API call
    const timer = setTimeout(() => {
      if (categoryId) {
        setProducts(getProductsByCategory(categoryId));
      }
      setIsLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, [categoryId]);

  const toggleFilter = () => {
    setIsFilterVisible(!isFilterVisible);
  };

  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSortBy(e.target.value);
    
    // Here you would implement actual sorting logic
    // This is just a placeholder for demonstration
    const sortedProducts = [...products];
    
    switch (e.target.value) {
      case 'price-low':
        sortedProducts.sort((a, b) => a.currentPrice - b.currentPrice);
        break;
      case 'price-high':
        sortedProducts.sort((a, b) => b.currentPrice - a.currentPrice);
        break;
      case 'newest':
        sortedProducts.sort((a, b) => new Date(b.dateAdded).getTime() - new Date(a.dateAdded).getTime());
        break;
      case 'rating':
        sortedProducts.sort((a, b) => b.rating - a.rating);
        break;
      default:
        // Popularity (default)
        sortedProducts.sort((a, b) => b.popularity - a.popularity);
    }
    
    setProducts(sortedProducts);
  };

  const handleFilterChange = (filters: Record<string, string[]>) => {
    setActiveFilters(filters);
    
    // Here you would implement actual filtering based on the selected filters
    // For demonstration, we'll just wait a bit and use the original list
    setIsLoading(true);
    
    setTimeout(() => {
      let filteredProducts = getProductsByCategory(categoryId || '');
      
      // Apply filters (simplified example)
      if (Object.keys(filters).length > 0) {
        Object.entries(filters).forEach(([groupId, selectedOptions]) => {
          if (selectedOptions.length > 0) {
            // This is a placeholder - real filtering would depend on your data structure
            if (groupId === 'sizes' && categoryId === 'clothes') {
              filteredProducts = filteredProducts.filter(p => 
                p.variants?.sizes?.some(s => selectedOptions.includes(s.id))
              );
            } else if (groupId === 'ageGroups' && categoryId === 'toys') {
              filteredProducts = filteredProducts.filter(p => 
                p.variants?.ageGroups?.some(a => selectedOptions.includes(a.id))
              );
            } else if (groupId === 'brands') {
              filteredProducts = filteredProducts.filter(p => 
                selectedOptions.includes(p.brand.toLowerCase().replace(' ', '-'))
              );
            }
          }
        });
      }
      
      setProducts(filteredProducts);
      setIsLoading(false);
    }, 800);
  };

  const displayName = categoryId === 'clothes' ? 'Clothing' : categoryId === 'toys' ? 'Toys' : 'Products';
  
  // Define filter groups based on category
  const filterGroups = categoryId === 'clothes' 
    ? [
        {
          id: 'sizes',
          name: 'Sizes',
          options: [
            { id: 'xs', label: 'XS' },
            { id: 's', label: 'S' },
            { id: 'm', label: 'M' },
            { id: 'l', label: 'L' },
            { id: 'xl', label: 'XL' },
            { id: 'xxl', label: 'XXL' },
          ]
        },
        {
          id: 'brands',
          name: 'Brands',
          options: [
            { id: 'nike', label: 'Nike' },
            { id: 'adidas', label: 'Adidas' },
            { id: 'puma', label: 'Puma' },
            { id: 'levis', label: 'Levi\'s' },
            { id: 'h-and-m', label: 'H&M' },
          ]
        },
        {
          id: 'colors',
          name: 'Colors',
          options: [
            { id: 'black', label: 'Black' },
            { id: 'white', label: 'White' },
            { id: 'red', label: 'Red' },
            { id: 'blue', label: 'Blue' },
            { id: 'green', label: 'Green' },
          ]
        },
        {
          id: 'price',
          name: 'Price Range',
          options: [
            { id: 'under-25', label: 'Under $25' },
            { id: '25-50', label: '$25 to $50' },
            { id: '50-100', label: '$50 to $100' },
            { id: 'over-100', label: 'Over $100' },
          ]
        }
      ]
    : categoryId === 'toys'
      ? [
          {
            id: 'ageGroups',
            name: 'Age Group',
            options: [
              { id: '0-2', label: '0-2 years' },
              { id: '3-5', label: '3-5 years' },
              { id: '6-8', label: '6-8 years' },
              { id: '9-12', label: '9-12 years' },
              { id: '12+', label: '12+ years' },
            ]
          },
          {
            id: 'brands',
            name: 'Brands',
            options: [
              { id: 'lego', label: 'LEGO' },
              { id: 'hasbro', label: 'Hasbro' },
              { id: 'mattel', label: 'Mattel' },
              { id: 'fisher-price', label: 'Fisher Price' },
              { id: 'nerf', label: 'Nerf' },
            ]
          },
          {
            id: 'price',
            name: 'Price Range',
            options: [
              { id: 'under-25', label: 'Under $25' },
              { id: '25-50', label: '$25 to $50' },
              { id: '50-100', label: '$50 to $100' },
              { id: 'over-100', label: 'Over $100' },
            ]
          }
        ]
      : [];

  return (
    <div className="container mx-auto px-4 py-8 pt-24">
      {/* Category Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 py-10 -mx-4 px-4 mb-8 rounded-b-3xl">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">{displayName}</h1>
          <p className="text-blue-100">
            Discover our collection of {categoryId === 'clothes' ? 'premium clothing items' : 'amazing toys'} for all ages
          </p>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-8">
        {/* Filters Sidebar - Desktop */}
        <div className="md:w-1/4 lg:w-1/5 hidden md:block">
          <div className="sticky top-24">
            <h2 className="text-lg font-bold mb-4">Filters</h2>
            <CategoryFilter 
              filterGroups={filterGroups} 
              onFilterChange={handleFilterChange}
              activeFilters={activeFilters}
            />
          </div>
        </div>

        {/* Main Content */}
        <div className="md:w-3/4 lg:w-4/5">
          {/* Mobile Filter Button */}
          <div className="md:hidden mb-4">
            <button
              onClick={toggleFilter}
              className="w-full py-2 px-4 bg-white border border-gray-300 rounded-lg shadow-sm flex items-center justify-between"
            >
              <div className="flex items-center">
                <Filter className="h-5 w-5 mr-2" />
                <span>Filters</span>
              </div>
              <span className="text-sm text-gray-500">
                {Object.values(activeFilters).reduce((count, filters) => count + filters.length, 0)} applied
              </span>
            </button>
          </div>

          {/* Mobile Filters Panel */}
          {isFilterVisible && (
            <div className="md:hidden mb-6">
              <CategoryFilter 
                filterGroups={filterGroups} 
                onFilterChange={handleFilterChange}
                activeFilters={activeFilters}
              />
            </div>
          )}

          {/* Toolbar */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
            <div>
              <p className="text-gray-600">
                {isLoading ? 'Loading...' : `Showing ${products.length} results`}
              </p>
            </div>
            <div className="flex items-center justify-between w-full sm:w-auto gap-4">
              <div>
                <label htmlFor="sort-by" className="sr-only">Sort by</label>
                <select
                  id="sort-by"
                  value={sortBy}
                  onChange={handleSortChange}
                  className="py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm"
                >
                  <option value="popularity">Popularity</option>
                  <option value="rating">Highest Rated</option>
                  <option value="newest">Newest</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                </select>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 rounded-md ${
                    viewMode === 'grid' 
                      ? 'bg-blue-100 text-blue-600' 
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  <Grid size={20} />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2 rounded-md ${
                    viewMode === 'list' 
                      ? 'bg-blue-100 text-blue-600' 
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  <List size={20} />
                </button>
              </div>
            </div>
          </div>

          {/* Products */}
          <ProductGrid products={products} isLoading={isLoading} />
          
          {/* Pagination would go here */}
          <div className="mt-8 flex justify-center">
            <nav className="flex items-center">
              <button className="px-3 py-1 border border-gray-300 rounded-l-md text-gray-700 hover:bg-gray-50 disabled:opacity-50">
                Previous
              </button>
              
              <button className="px-3 py-1 border-t border-b border-gray-300 bg-blue-50 text-blue-600">
                1
              </button>
              
              <button className="px-3 py-1 border-t border-b border-gray-300 text-gray-700 hover:bg-gray-50">
                2
              </button>
              
              <button className="px-3 py-1 border-t border-b border-gray-300 text-gray-700 hover:bg-gray-50">
                3
              </button>
              
              <span className="px-3 py-1 border-t border-b border-gray-300 text-gray-700">
                ...
              </span>
              
              <button className="px-3 py-1 border-t border-b border-gray-300 text-gray-700 hover:bg-gray-50">
                10
              </button>
              
              <button className="px-3 py-1 border border-gray-300 rounded-r-md text-gray-700 hover:bg-gray-50">
                Next
              </button>
            </nav>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CategoryPage;